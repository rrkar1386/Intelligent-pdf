# Smart PDF Reader V3

V3 is an incremental improvement over the APK-producing V2 build.

## What V3 fixes

1. **Preserves classified reading order**
   - V2 detected two-column pages but then globally sorted all blocks by Y position.
   - That re-interleaved left and right columns.
   - V3 keeps the order produced by the page-region classifier.

2. **Keeps figures with their detected captions**
   - Caption-associated visuals are inserted immediately before their caption.
   - They are no longer globally sorted by page Y position.

3. **Repairs the demonstrated duplicated-glyph extraction artefact**
   - Handles exact character-pair duplication such as `TThhee`, `CCaanncceerr` and `UUMMaassss`.
   - The repair is deliberately conservative and only applies to an entire token whose characters occur as identical pairs.

4. **More conservative heading detection**
   - Reduces the chance that ordinary prose is promoted to a heading.
   - Captions are excluded from heading classification.

5. **Keeps V2's working architecture**
   - PDFBox text extraction
   - Android PdfRenderer original view
   - SAF PDF opening
   - memory-bounded PDF loading
   - existing visual crop approach
   - conservative column detection

## Build

The repository root is the Android Gradle project itself. The GitHub Actions workflow therefore verifies and builds `settings.gradle`, `build.gradle` and `app/` directly from the checkout root.

Artifact: `SmartPDFReader-V3-debug`

## Benchmark

Compare V3 reading output with the original PDFs used for V2 testing, especially:
- The Pathology of Cancer
- History of Neurology in the Netherlands

V3 is accepted only if it both improves the reading output and produces a valid debug APK.
