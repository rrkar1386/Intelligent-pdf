package com.smartpdfreader

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.graphics.PDXObject
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import kotlinx.coroutines.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Smart PDF Reader V1. The original PDF remains the source of truth. */
class MainActivity : AppCompatActivity() {
    private lateinit var title: TextView
    private lateinit var open: Button
    private lateinit var mode: Button
    private lateinit var progress: ProgressBar
    private lateinit var readingScroll: ScrollView
    private lateinit var readingContainer: LinearLayout
    private lateinit var originalScroll: ScrollView
    private lateinit var originalContainer: LinearLayout
    private var currentUri: Uri? = null
    private var documentModel: ReadingDocument? = null
    private var readingMode = true
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            load(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContentView(R.layout.activity_main)
        title = findViewById(R.id.titleText); open = findViewById(R.id.importButton); mode = findViewById(R.id.modeButton)
        progress = findViewById(R.id.progress); readingScroll = findViewById(R.id.readingScroll); readingContainer = findViewById(R.id.readingContainer)
        originalScroll = findViewById(R.id.originalScroll); originalContainer = findViewById(R.id.originalContainer)
        open.setOnClickListener { picker.launch(arrayOf("application/pdf")) }
        mode.setOnClickListener { readingMode = !readingMode; render() }
    }

    private fun load(uri: Uri) {
        currentUri = uri; progress.visibility = View.VISIBLE; open.isEnabled = false
        scope.launch {
            try {
                val m = withContext(Dispatchers.IO) { analyze(uri) }
                documentModel = m; title.text = m.title; mode.visibility = View.VISIBLE; readingMode = true; render()
            } catch (e: Throwable) {
                Toast.makeText(this@MainActivity, "Could not open PDF: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
            } finally { progress.visibility = View.GONE; open.isEnabled = true }
        }
    }

    private fun analyze(uri: Uri): ReadingDocument {
        val fd = contentResolver.openFileDescriptor(uri, "r") ?: error("Unable to open PDF")
        fd.use { pfd -> PDDocument.load(pfd.fileDescriptor).use { doc ->
            val pages = (0 until doc.numberOfPages).map { analyzePage(doc, it) }
            return ReadingDocument(queryName(uri) ?: "PDF", pages)
        }}
    }

    private fun analyzePage(doc: PDDocument, index: Int): PageModel {
        val page = doc.getPage(index)
        val positions = mutableListOf<TextPosition>()
        val stripper = object : PDFTextStripper() {
            override fun processTextPosition(tp: TextPosition): Boolean { positions += tp; return true }
        }
        stripper.sortByPosition = false; stripper.startPage = index + 1; stripper.endPage = index + 1; stripper.getText(doc)
        val lines = makeLines(positions)
        val text = makeBlocks(lines, page.mediaBox.width)
        val visuals = detectEmbeddedImages(page)
        val objects = mutableListOf<ReadingBlock>()
        objects += text.map { ReadingBlock.Text(it.text, index, it.top, it.bottom, it.left, it.right) }
        objects += visuals.map { ReadingBlock.Visual(index, it.top, it.bottom, it.left, it.right, it.bytes) }
        return PageModel(index, page.mediaBox.width, page.mediaBox.height, objects.sortedWith(compareBy<ReadingBlock>{it.top}.thenBy{it.left}))
    }

    private fun makeLines(chars: List<TextPosition>): List<Line> {
        if (chars.isEmpty()) return emptyList()
        val sorted = chars.sortedWith(compareBy<TextPosition>{it.y}.thenBy{it.x})
        val lines = mutableListOf<MutableList<TextPosition>>()
        for (c in sorted) {
            val last = lines.lastOrNull()
            if (last == null || abs(last[0].y - c.y) > 3f) lines += mutableListOf(c) else last += c
        }
        return lines.mapNotNull { row ->
            val r = row.sortedBy { it.x }; val s = wordAware(r).trim()
            if (s.isBlank()) null else Line(s, r.minOf{it.x}, r.maxOf{it.x+it.width}, r.minOf{it.y}, r.maxOf{it.y+it.height})
        }
    }

    private fun wordAware(chars: List<TextPosition>): String {
        val out = StringBuilder()
        for (i in chars.indices) {
            val c = chars[i]
            if (i > 0) {
                val p = chars[i-1]; val gap = c.x - (p.x+p.width); val avg = max(.5f,(p.width+c.width)/2f)
                if ((gap > avg*.55f || p.unicode?.contains(" ")==true) && out.isNotEmpty() && !out.last().isWhitespace()) out.append(' ')
            }
            out.append(c.unicode ?: "")
        }
        return out.toString().replace(Regex("[ \\t]+"), " ")
    }

    private fun makeBlocks(lines: List<Line>, pageWidth: Float): List<Block> {
        val out = mutableListOf<Block>(); var cur = mutableListOf<Line>()
        fun flush() { if (cur.isNotEmpty()) { out += Block(cur.joinToString(" "){it.text}.replace(Regex("\\s+")," ").trim(),cur.minOf{it.left},cur.maxOf{it.right},cur.minOf{it.top},cur.maxOf{it.bottom}); cur=mutableListOf() } }
        for (l in lines.sortedWith(compareBy<Line>{it.top}.thenBy{it.left})) {
            if (cur.isEmpty()) { cur += l; continue }
            val p=cur.last(); val gap=l.top-p.bottom; val columnJump=abs(l.left-p.left)>pageWidth*.28f
            if (gap>p.bottom-p.top*.9f || columnJump) flush()
            cur += l
        }
        flush(); return out
    }

    private fun detectEmbeddedImages(page: PDPage): List<Visual> {
        val out=mutableListOf<Visual>(); val res=page.resources ?: return out
        for (name in res.xObjectNames) try {
            val x: PDXObject=res.getXObject(name)
            if (x is PDImageXObject) {
                val bmp=x.image ?: continue; val bytes=java.io.ByteArrayOutputStream().also{bmp.compress(Bitmap.CompressFormat.PNG,100,it)}.toByteArray()
                val w=page.mediaBox.width; val h=page.mediaBox.height; val tw=w*.88f; val th=min(h*.42f,tw* bmp.height.toFloat()/max(1,bmp.width))
                val top=h*.25f; out += Visual(top,top+th,(w-tw)/2f,(w+tw)/2f,bytes)
            }
        } catch (_: Throwable) {}
        return out
    }

    private fun render() {
        val m=documentModel ?: return
        if (readingMode) { mode.text="Original"; readingScroll.visibility=View.VISIBLE; originalScroll.visibility=View.GONE; renderReading(m) }
        else { mode.text="Reading"; readingScroll.visibility=View.GONE; originalScroll.visibility=View.VISIBLE; renderOriginal(m) }
    }

    private fun renderReading(m: ReadingDocument) {
        readingContainer.removeAllViews()
        for (p in m.pages) {
            val label=TextView(this).apply{text="Page ${p.index+1}";textSize=12f;setTextColor(Color.GRAY);setPadding(4,14,4,6)}; readingContainer.addView(label)
            for (b in p.blocks) when(b) {
                is ReadingBlock.Text -> readingContainer.addView(TextView(this).apply{text=b.text;textSize=18f;setTextColor(ContextCompat.getColor(this@MainActivity,R.color.reader_text));setLineSpacing(0f,1.18f);setPadding(4,5,4,9)})
                is ReadingBlock.Visual -> { val bmp=android.graphics.BitmapFactory.decodeByteArray(b.bytes,0,b.bytes.size); if(bmp!=null) readingContainer.addView(ImageView(this).apply{setImageBitmap(bmp);adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_CENTER;setPadding(0,10,0,10);setOnClickListener{jumpToPage(b.page)}}) }
            }
        }
    }

    private fun renderOriginal(m: ReadingDocument) {
        originalContainer.removeAllViews(); for(p in m.pages){ val bmp=renderPage(p.index) ?: continue; originalContainer.addView(ImageView(this).apply{setImageBitmap(bmp);adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_CENTER;setPadding(0,0,0,12)}) }
    }

    private fun renderPage(index:Int):Bitmap? = try { contentResolver.openFileDescriptor(currentUri ?: return null,"r")?.use { fd -> android.graphics.pdf.PdfRenderer(fd).use { r -> if(index>=r.pageCount)null else r.openPage(index).use { pg -> val w=1000; val h=(w.toFloat()*pg.height/pg.width).toInt(); Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888).also{it.eraseColor(Color.WHITE);pg.render(it,null,null,android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)} } } } } catch(_:Throwable){null}

    private fun jumpToPage(page:Int){ readingMode=false; render(); originalScroll.post{originalContainer.getChildAt(page)?.let{originalScroll.smoothScrollTo(0,it.top)} } }
    private fun queryName(uri:Uri):String? { contentResolver.query(uri,arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())return it.getString(0)};return null }
    override fun onDestroy(){scope.cancel();super.onDestroy()}

    data class ReadingDocument(val title:String,val pages:List<PageModel>)
    data class PageModel(val index:Int,val width:Float,val height:Float,val blocks:List<ReadingBlock>)
    sealed class ReadingBlock { abstract val page:Int; abstract val top:Float; abstract val bottom:Float; abstract val left:Float; abstract val right:Float
        data class Text(val text:String,override val page:Int,override val top:Float,override val bottom:Float,override val left:Float,override val right:Float):ReadingBlock()
        data class Visual(override val page:Int,override val top:Float,override val bottom:Float,override val left:Float,override val right:Float,val bytes:ByteArray):ReadingBlock()
    }
    data class Line(val text:String,val left:Float,val right:Float,val top:Float,val bottom:Float)
    data class Block(val text:String,val left:Float,val right:Float,val top:Float,val bottom:Float)
    data class Visual(val top:Float,val bottom:Float,val left:Float,val right:Float,val bytes:ByteArray)
}
