package com.smartpdfreader

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.graphics.PDXObject
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Smart PDF Reader V1.
 *
 * The source PDF is never modified. V1 builds a page-aware reading model
 * and keeps a page-rendered Original mode for verification and navigation.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var title: TextView
    private lateinit var openButton: Button
    private lateinit var modeButton: Button
    private lateinit var progress: ProgressBar
    private lateinit var readingScroll: ScrollView
    private lateinit var readingContainer: LinearLayout
    private lateinit var originalScroll: RecyclerView

    private var currentUri: Uri? = null
    private var documentModel: ReadingDocument? = null
    private var readingMode = true

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {
                    // Some document providers do not offer persistable permissions.
                }
                load(uri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        PDFBoxResourceLoader.init(applicationContext)
        setContentView(R.layout.activity_main)

        title = findViewById(R.id.titleText)
        openButton = findViewById(R.id.importButton)
        modeButton = findViewById(R.id.modeButton)
        progress = findViewById(R.id.progress)
        readingScroll = findViewById(R.id.readingScroll)
        readingContainer = findViewById(R.id.readingContainer)
        originalScroll = findViewById(R.id.originalScroll)
        originalScroll.layoutManager = LinearLayoutManager(this)

        openButton.setOnClickListener {
            picker.launch(arrayOf("application/pdf"))
        }

        modeButton.setOnClickListener {
            readingMode = !readingMode
            render()
        }
    }

    private fun load(uri: Uri) {
        currentUri = uri
        progress.visibility = View.VISIBLE
        openButton.isEnabled = false

        scope.launch {
            try {
                val model = withContext(Dispatchers.IO) {
                    analyze(uri)
                }

                documentModel = model
                title.text = model.title
                modeButton.visibility = View.VISIBLE
                readingMode = true
                render()
            } catch (e: Throwable) {
                Toast.makeText(
                    this@MainActivity,
                    "Could not open PDF: ${e.message ?: "unknown error"}",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                progress.visibility = View.GONE
                openButton.isEnabled = true
            }
        }
    }

    /**
     * PDFBox 2.0.27 on Android accepts an InputStream.
     * Using ContentResolver.openInputStream also works with SAF document URIs
     * without requiring a filesystem path.
     */
    private fun analyze(uri: Uri): ReadingDocument {
        val input = contentResolver.openInputStream(uri)
            ?: error("Unable to open PDF")

        input.use { stream ->
            PDDocument.load(
                stream,
                MemoryUsageSetting.setupMixed(32L * 1024L * 1024L)
            ).use { document ->
                val pages = (0 until document.numberOfPages).map { index ->
                    analyzePage(document, index)
                }

                return ReadingDocument(
                    title = queryName(uri) ?: "PDF",
                    pages = pages
                )
            }
        }
    }

    private fun analyzePage(document: PDDocument, index: Int): PageModel {
        val page = document.getPage(index)
        val positions = mutableListOf<TextPosition>()

        val stripper = object : PDFTextStripper() {
            override fun processTextPosition(text: TextPosition) {
                positions += text
            }
        }

        stripper.sortByPosition = false
        stripper.startPage = index + 1
        stripper.endPage = index + 1
        stripper.getText(document)

        val lines = makeLines(positions)
        val textBlocks = makeBlocks(lines, page.mediaBox.width)
        val visuals = detectEmbeddedImages(page)

        val objects = mutableListOf<ReadingBlock>()

        objects += textBlocks.map {
            ReadingBlock.Text(
                text = it.text,
                page = index,
                top = it.top,
                bottom = it.bottom,
                left = it.left,
                right = it.right
            )
        }

        /*
         * V1 only inserts visual objects when PDFBox exposes them as page
         * XObjects. Their exact placement is not yet inferred from the
         * content-stream transform, so they are deliberately kept as
         * page-level visual objects rather than inventing a false position.
         */
        objects += visuals.map {
            ReadingBlock.Visual(
                page = index,
                top = it.top,
                bottom = it.bottom,
                left = it.left,
                right = it.right,
                bytes = it.bytes
            )
        }

        val ordered = orderPageObjects(
            objects = objects,
            pageWidth = page.mediaBox.width
        )

        return PageModel(
            index = index,
            width = page.mediaBox.width,
            height = page.mediaBox.height,
            blocks = ordered
        )
    }

    private fun makeLines(chars: List<TextPosition>): List<Line> {
        if (chars.isEmpty()) return emptyList()

        val sorted = chars.sortedWith(
            compareBy<TextPosition> { it.y }.thenBy { it.x }
        )

        val rows = mutableListOf<MutableList<TextPosition>>()

        for (character in sorted) {
            val last = rows.lastOrNull()

            if (last == null) {
                rows += mutableListOf(character)
                continue
            }

            val referenceY = last.first().y
            val tolerance = max(2.5f, character.height * 0.35f)

            if (abs(referenceY - character.y) <= tolerance) {
                last += character
            } else {
                rows += mutableListOf(character)
            }
        }

        return rows.mapNotNull { row ->
            val ordered = row.sortedBy { it.x }
            val text = wordAware(ordered).trim()

            if (text.isBlank()) {
                null
            } else {
                Line(
                    text = text,
                    left = ordered.minOf { it.x },
                    right = ordered.maxOf { it.x + it.width },
                    top = ordered.minOf { it.y },
                    bottom = ordered.maxOf { it.y + it.height }
                )
            }
        }
    }

    private fun wordAware(chars: List<TextPosition>): String {
        val out = StringBuilder()

        for (i in chars.indices) {
            val current = chars[i]

            if (i > 0) {
                val previous = chars[i - 1]
                val gap = current.x - (previous.x + previous.width)
                val averageWidth = max(
                    0.5f,
                    (previous.width + current.width) / 2f
                )

                if (
                    gap > averageWidth * 0.55f &&
                    out.isNotEmpty() &&
                    !out.last().isWhitespace()
                ) {
                    out.append(' ')
                }
            }

            out.append(current.unicode ?: "")
        }

        return out.toString().replace(Regex("[ \\t]+"), " ")
    }

    /**
     * Reconstruct paragraphs inside simple column regions.
     *
     * This is intentionally conservative: if the page does not clearly
     * resemble two columns, normal top-to-bottom ordering is retained.
     */
    private fun makeBlocks(lines: List<Line>, pageWidth: Float): List<Block> {
        if (lines.isEmpty()) return emptyList()

        val columnized = splitIntoColumns(lines, pageWidth)
        val result = mutableListOf<Block>()

        for (column in columnized) {
            var current = mutableListOf<Line>()

            fun flush() {
                if (current.isEmpty()) return

                val text = current.joinToString(" ") { it.text }
                    .replace(Regex("\\s+"), " ")
                    .trim()

                if (text.isNotEmpty()) {
                    result += Block(
                        text = text,
                        left = current.minOf { it.left },
                        right = current.maxOf { it.right },
                        top = current.minOf { it.top },
                        bottom = current.maxOf { it.bottom }
                    )
                }

                current = mutableListOf()
            }

            for (line in column.sortedWith(
                compareBy<Line> { it.top }.thenBy { it.left }
            )) {
                if (current.isEmpty()) {
                    current += line
                    continue
                }

                val previous = current.last()
                val lineHeight = max(
                    1f,
                    previous.bottom - previous.top
                )
                val verticalGap = line.top - previous.bottom
                val indentShift = abs(line.left - previous.left)

                /*
                 * Keep normal paragraph lines together. A clearly larger
                 * vertical gap or a strong indentation/position change
                 * starts a new structural block.
                 */
                val newBlock =
                    verticalGap > lineHeight * 1.15f ||
                    (indentShift > pageWidth * 0.10f &&
                        verticalGap > lineHeight * 0.20f)

                if (newBlock) {
                    flush()
                }

                current += line
            }

            flush()
        }

        return result
    }

    /**
     * Detect a clear two-column layout without forcing every page into
     * columns. Full-width lines are left in the normal flow.
     */
    private fun splitIntoColumns(
        lines: List<Line>,
        pageWidth: Float
    ): List<List<Line>> {
        val left = mutableListOf<Line>()
        val right = mutableListOf<Line>()
        val fullWidth = mutableListOf<Line>()

        val midpoint = pageWidth / 2f
        val gutter = pageWidth * 0.055f

        for (line in lines) {
            val spansCenter = line.left < midpoint - gutter &&
                line.right > midpoint + gutter

            if (spansCenter || line.right - line.left > pageWidth * 0.72f) {
                fullWidth += line
            } else if (line.right <= midpoint - gutter) {
                left += line
            } else if (line.left >= midpoint + gutter) {
                right += line
            } else {
                fullWidth += line
            }
        }

        val hasTwoColumns =
            left.size >= 8 &&
            right.size >= 8 &&
            left.size.toFloat() / max(1, lines.size) > 0.20f &&
            right.size.toFloat() / max(1, lines.size) > 0.20f

        if (!hasTwoColumns) {
            return listOf(lines.sortedWith(
                compareBy<Line> { it.top }.thenBy { it.left }
            ))
        }

        /*
         * Full-width headings/labels are kept before/after the column flow
         * according to their vertical position. For a simple two-column
         * page, the columns themselves are read left then right.
         */
        val columnFlow = mutableListOf<List<Line>>()

        if (fullWidth.isNotEmpty()) {
            val earlyFull = fullWidth.filter { it.top <= minOf(
                left.minOf { l -> l.top },
                right.minOf { l -> l.top }
            ) }

            if (earlyFull.isNotEmpty()) {
                columnFlow += earlyFull.sortedBy { it.top }
            }
        }

        columnFlow += left.sortedWith(
            compareBy<Line> { it.top }.thenBy { it.left }
        )
        columnFlow += right.sortedWith(
            compareBy<Line> { it.top }.thenBy { it.left }
        )

        val lateFull = fullWidth.filter { line ->
            line !in columnFlow.flatten()
        }.sortedBy { it.top }

        if (lateFull.isNotEmpty()) {
            columnFlow += lateFull
        }

        return columnFlow
    }

    private fun detectEmbeddedImages(page: PDPage): List<Visual> {
        val resources = page.resources ?: return emptyList()
        val result = mutableListOf<Visual>()
        val maxImagesPerPage = 3

        for (name in resources.xObjectNames) {
            if (result.size >= maxImagesPerPage) break

            try {
                val xObject: PDXObject = resources.getXObject(name)

                if (xObject is PDImageXObject) {
                    val original = xObject.image ?: continue

                    /*
                     * Keep analysis memory bounded. We store only a
                     * reader-sized copy of each detected image, not the
                     * original full-resolution bitmap.
                     */
                    val maxDimension = 1400
                    val scale = min(
                        1f,
                        min(
                            maxDimension.toFloat() / max(1, original.width),
                            maxDimension.toFloat() / max(1, original.height)
                        )
                    )

                    val bitmap =
                        if (scale < 1f) {
                            Bitmap.createScaledBitmap(
                                original,
                                max(1, (original.width * scale).toInt()),
                                max(1, (original.height * scale).toInt()),
                                true
                            )
                        } else {
                            original
                        }

                    val bitmapWidth = max(1, bitmap.width)
                    val bitmapHeight = max(1, bitmap.height)

                    val bytes = java.io.ByteArrayOutputStream().use { output ->
                        bitmap.compress(
                            Bitmap.CompressFormat.JPEG,
                            82,
                            output
                        )
                        output.toByteArray()
                    }

                    if (bitmap !== original) {
                        bitmap.recycle()
                        original.recycle()
                    }

                    /*
                     * Exact image placement is intentionally not guessed.
                     * The object remains associated with its source page
                     * and is rendered after that page's text in V1.
                     */
                    val pageWidth = page.mediaBox.width
                    val pageHeight = page.mediaBox.height
                    val targetWidth = pageWidth * 0.88f
                    val aspect = bitmapHeight.toFloat() /
                        bitmapWidth.toFloat()
                    val targetHeight = min(
                        pageHeight * 0.42f,
                        targetWidth * aspect
                    )

                    result += Visual(
                        top = pageHeight * 0.25f,
                        bottom = pageHeight * 0.25f + targetHeight,
                        left = (pageWidth - targetWidth) / 2f,
                        right = (pageWidth + targetWidth) / 2f,
                        bytes = bytes
                    )
                }
            } catch (_: Throwable) {
                // One malformed/unsupported visual must not abort the PDF.
            }
        }

        return result
    }


    private fun orderPageObjects(
        objects: List<ReadingBlock>,
        pageWidth: Float
    ): List<ReadingBlock> {
        if (objects.isEmpty()) return emptyList()

        val visuals = objects.filterIsInstance<ReadingBlock.Visual>()
        val text = objects.filterIsInstance<ReadingBlock.Text>()

        if (visuals.isEmpty()) {
            return text
        }

        /*
         * Until exact image transforms are implemented, keep visuals at
         * the end of their source page rather than inserting them at a
         * fabricated coordinate that could split a paragraph incorrectly.
         *
         * The text list already contains the deliberate single-column or
         * left-column-then-right-column reading order produced above.
         */
        return text + visuals
    }

    private fun render() {
        val model = documentModel ?: return

        if (readingMode) {
            modeButton.text = "Original"
            readingScroll.visibility = View.VISIBLE
            originalScroll.visibility = View.GONE
            renderReading(model)
        } else {
            modeButton.text = "Reading"
            readingScroll.visibility = View.GONE
            originalScroll.visibility = View.VISIBLE
            renderOriginal(model)
        }
    }

    private fun renderReading(model: ReadingDocument) {
        readingContainer.removeAllViews()

        for (page in model.pages) {
            val pageLabel = TextView(this).apply {
                text = "Page ${page.index + 1}"
                textSize = 12f
                setTextColor(Color.GRAY)
                setPadding(4, 14, 4, 6)
            }

            readingContainer.addView(pageLabel)

            for (block in page.blocks) {
                when (block) {
                    is ReadingBlock.Text -> {
                        readingContainer.addView(
                            TextView(this).apply {
                                text = block.text
                                textSize = 18f
                                setTextColor(
                                    ContextCompat.getColor(
                                        this@MainActivity,
                                        R.color.reader_text
                                    )
                                )
                                setLineSpacing(0f, 1.18f)
                                setPadding(4, 5, 4, 9)
                            }
                        )
                    }

                    is ReadingBlock.Visual -> {
                        val bitmap = BitmapFactory.decodeByteArray(
                            block.bytes,
                            0,
                            block.bytes.size
                        )

                        if (bitmap != null) {
                            val visualLabel = TextView(this).apply {
                                text = "Visual from page ${block.page + 1}"
                                textSize = 12f
                                setTextColor(Color.GRAY)
                                setPadding(4, 8, 4, 2)
                            }

                            readingContainer.addView(visualLabel)

                            readingContainer.addView(
                                ImageView(this).apply {
                                    setImageBitmap(bitmap)
                                    adjustViewBounds = true
                                    scaleType = ImageView.ScaleType.FIT_CENTER
                                    setPadding(0, 8, 0, 12)
                                    setOnClickListener {
                                        jumpToPage(block.page)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun renderOriginal(model: ReadingDocument) {
        originalScroll.adapter = OriginalPageAdapter(model.pages.size)
    }

    private inner class OriginalPageAdapter(
        private val pageCount: Int
    ) : RecyclerView.Adapter<OriginalPageAdapter.PageHolder>() {

        override fun onCreateViewHolder(
            parent: android.view.ViewGroup,
            viewType: Int
        ): PageHolder {
            val image = ImageView(parent.context).apply {
                layoutParams = RecyclerView.LayoutParams(
                    RecyclerView.LayoutParams.MATCH_PARENT,
                    RecyclerView.LayoutParams.WRAP_CONTENT
                ).also {
                    it.bottomMargin = 12
                }
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(Color.WHITE)
            }

            return PageHolder(image)
        }

        override fun onBindViewHolder(holder: PageHolder, position: Int) {
            holder.boundPage = position
            holder.image.setImageDrawable(null)

            scope.launch {
                val bitmap = withContext(Dispatchers.IO) {
                    renderPage(position)
                }

                if (holder.boundPage == position && bitmap != null) {
                    holder.image.setImageBitmap(bitmap)
                }
            }
        }

        override fun onViewRecycled(holder: PageHolder) {
            holder.boundPage = RecyclerView.NO_POSITION
            holder.image.setImageDrawable(null)
            super.onViewRecycled(holder)
        }

        override fun getItemCount(): Int = pageCount

        inner class PageHolder(
            val image: ImageView
        ) : RecyclerView.ViewHolder(image) {
            var boundPage: Int = RecyclerView.NO_POSITION
        }
    }

    /**
     * Android's PdfRenderer is used only for faithful Original-mode display.
     * It requires a ParcelFileDescriptor, not a java.io.File.
     */
    private fun renderPage(index: Int): Bitmap? {
        val uri = currentUri ?: return null

        return try {
            val descriptor = contentResolver.openFileDescriptor(uri, "r")
                ?: return null

            descriptor.use { fd ->
                PdfRenderer(fd).use { renderer ->
                    if (index < 0 || index >= renderer.pageCount) {
                        return null
                    }

                    renderer.openPage(index).use { page ->
                        val width = 1000
                        val height = max(
                            1,
                            (width.toFloat() * page.height / page.width).toInt()
                        )

                        Bitmap.createBitmap(
                            width,
                            height,
                            Bitmap.Config.ARGB_8888
                        ).also { bitmap ->
                            bitmap.eraseColor(Color.WHITE)
                            page.render(
                                bitmap,
                                null,
                                null,
                                PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
                            )
                        }
                    }
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun jumpToPage(page: Int) {
        readingMode = false
        render()
        originalScroll.post {
            originalScroll.smoothScrollToPosition(
                page.coerceIn(0, max(0, (documentModel?.pages?.size ?: 1) - 1))
            )
        }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(
            uri,
            arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                return cursor.getString(0)
            }
        }

        return null
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    data class ReadingDocument(
        val title: String,
        val pages: List<PageModel>
    )

    data class PageModel(
        val index: Int,
        val width: Float,
        val height: Float,
        val blocks: List<ReadingBlock>
    )

    sealed class ReadingBlock {
        abstract val page: Int
        abstract val top: Float
        abstract val bottom: Float
        abstract val left: Float
        abstract val right: Float

        data class Text(
            val text: String,
            override val page: Int,
            override val top: Float,
            override val bottom: Float,
            override val left: Float,
            override val right: Float
        ) : ReadingBlock()

        data class Visual(
            override val page: Int,
            override val top: Float,
            override val bottom: Float,
            override val left: Float,
            override val right: Float,
            val bytes: ByteArray
        ) : ReadingBlock()
    }

    data class Line(
        val text: String,
        val left: Float,
        val right: Float,
        val top: Float,
        val bottom: Float
    )

    data class Block(
        val text: String,
        val left: Float,
        val right: Float,
        val top: Float,
        val bottom: Float
    )

    data class Visual(
        val top: Float,
        val bottom: Float,
        val left: Float,
        val right: Float,
        val bytes: ByteArray
    )
}
