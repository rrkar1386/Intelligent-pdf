# Smart PDF Reader V1

A new Android PDF reader project focused on a phone-optimized reading mode rather than PDF→EPUB conversion.

## V1 foundation
- Import local PDFs.
- Keep the original PDF available.
- Extract text and coordinates with PDFBox.
- Build a page-aware reading model.
- Reconstruct basic text blocks with geometry-aware word spacing.
- Detect embedded visual objects.
- Place detected visual objects in the page reading stream.
- Provide Original mode and source-page navigation.
- Build via `.github/workflows/build.yml`.

## Deliberate scope
This is the first foundation build. It does not claim that complex columns, captions, diagrams, tables, equations, scanned PDFs, or all figure placements are solved. Those will be developed against the agreed complex-PDF benchmark rather than hidden behind an EPUB conversion layer.
