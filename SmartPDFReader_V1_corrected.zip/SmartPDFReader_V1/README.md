# Smart PDF Reader V1

Smart PDF Reader V1 is an Android PDF reader prototype focused on a comfortable
phone reading view while preserving the original PDF as the source of truth.

## Current foundation

- Imports local PDFs through Android's document picker.
- Uses PDFBox Android 2.0.27.0 for text extraction and geometry.
- Builds a page-aware reading model.
- Reconstructs basic paragraphs from text coordinates.
- Detects conservative two-column pages and reads left column before right column.
- Keeps source-page numbers with reading blocks.
- Keeps an Original mode rendered from the actual PDF.
- Uses a RecyclerView for Original mode so large documents do not require
  every rendered page bitmap to remain in memory simultaneously.
- Uses bounded PDFBox mixed-memory buffering.
- Keeps visual objects associated with their source page.

## Deliberate limitations

This is a foundation build, not the finished complex-PDF engine.

Exact placement and association of figures, captions, tables, equations,
flowcharts, vector diagrams, footnotes, headers/footers and unusual multi-column
layouts are not yet claimed to be solved. In particular, V1 does **not** invent
an image position when the PDF content stream does not yet provide a reliable
placement model.

That limitation is intentional: a false association is worse than a
conservative source-page association.

The next development phase should use the complex-PDF benchmark and improve
visual-object geometry, caption attachment, table/paired-structure detection,
and reading-order confidence without sacrificing the Original PDF view.
