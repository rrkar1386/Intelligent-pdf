# Smart PDF Reader V4

V4 is a layout-order improvement over the APK-producing V3 baseline.

## Main change

V3 could still merge glyphs from two PDF columns into a single horizontal
line before column detection. V4 separates spatial line fragments first,
then determines page columns and reading order.

This targets the demonstrated Cancer PDF failure where left- and right-column
sentences were interleaved.

## Preserved

- PDFBox text extraction
- memory-bounded PDF loading
- source-page mapping
- figure/caption visual handling
- original PDF mode
- conservative page-furniture filtering
- duplicated-glyph repair
- heading/caption rendering
- GitHub Actions APK build

## Build

The Android project is at repository root.

Artifact:
`SmartPDFReader-V4-debug`
