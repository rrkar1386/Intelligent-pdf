# Smart PDF Reader V2 foundation

This build keeps the original PDF as the source of truth and improves the
phone reading view without rewriting the whole project.

## Improvements in this build

- Removes repeated PDF page furniture such as running headers, footers,
  printer metadata and isolated page numbers from the reading stream.
- Repairs the private-use digit encoding found in the historical neuroanatomy
  PDF (U+F730..U+F739 -> 0..9).
- Removes common line-break hyphenation when a word is split across extracted
  PDF lines.
- Detects headings from the source typography and gives them a clear reading
  hierarchy.
- Detects figure/table captions and places associated visuals before the
  caption instead of appending every visual to the end of the page.
- Uses an actual PDF-rendered crop for visuals, so vector artwork and raster
  images are preserved rather than depending only on PDF image extraction.
- Retains conservative two-column reading order for layouts such as the
  pathology glossary.
- Keeps the faithful Original mode for verification.

## Important architectural rule

This is still an incremental engine change. Existing PDF opening, the original
PDF renderer, SAF document access, bounded PDFBox memory usage and conservative
column handling are retained. The next changes should be made against this
build only after comparing representative difficult pages from the benchmark
PDFs.
