package com.smartpdfreader

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.graphics.PDXObject
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Smart PDF Reader V2 foundation.
 *
 * The source PDF remains the source of truth. The reading view reconstructs
 * logical text blocks, removes repeated page furniture, repairs common PDF
 * font-encoding artefacts, and places detected figure/table visuals before
 * their captions instead of appending all visuals at the end of a page.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var title: TextView
    private lateinit var openButton: Button
    private lateinit var modeButton: Button
    private lateinit var progress: ProgressBar
    private lateinit var readingScroll: ScrollView
    private lateinit var readingContainer: LinearLayout
    private lateinit var originalScroll: RecyclerView

    private var currentUri: Uri? = null
    private var documentModel: ReadingDocument? = null
    private var readingMode = true

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {
                    // Some document providers do not offer persistable permissions.
                }
                load(uri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        PDFBoxResourceLoader.init(applicationContext)
        setContentView(R.layout.activity_main)

        title = findViewById(R.id.titleText)
        openButton = findViewById(R.id.importButton)
        modeButton = findViewById(R.id.modeButton)
        progress = findViewById(R.id.progress)
        readingScroll = findViewById(R.id.readingScroll)
        readingContainer = findViewById(R.id.readingContainer)
        originalScroll = findViewById(R.id.originalScroll)
        originalScroll.layoutManager = LinearLayoutManager(this)

        openButton.setOnClickListener {
            picker.launch(arrayOf("application/pdf"))
        }

        modeButton.setOnClickListener {
            readingMode = !readingMode
            render()
        }
    }

    private fun load(uri: Uri) {
        currentUri = uri
        progress.visibility = View.VISIBLE
        openButton.isEnabled = false

        scope.launch {
            try {
                val model = withContext(Dispatchers.IO) { analyze(uri) }
                documentModel = model
                title.text = model.title
                modeButton.visibility = View.VISIBLE
                readingMode = true
                render()
            } catch (e: Throwable) {
                Toast.makeText(
                    this@MainActivity,
                    "Could not open PDF: ${e.message ?: "unknown error"}",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                progress.visibility = View.GONE
                openButton.isEnabled = true
            }
        }
    }

    private fun analyze(uri: Uri): ReadingDocument {
        val input = contentResolver.openInputStream(uri)
            ?: error("Unable to open PDF")

        input.use { stream ->
            PDDocument.load(
                stream,
                MemoryUsageSetting.setupMixed(32L * 1024L * 1024L)
            ).use { document ->
                val pages = (0 until document.numberOfPages).map { index ->
                    analyzePage(document, index)
                }

                return ReadingDocument(
                    title = queryName(uri) ?: "PDF",
                    pages = pages
                )
            }
        }
    }

    private fun analyzePage(document: PDDocument, index: Int): PageModel {
        val page = document.getPage(index)
        val positions = mutableListOf<TextPosition>()

        val stripper = object : PDFTextStripper() {
            override fun processTextPosition(text: TextPosition) {
                positions += text
            }
        }

        stripper.sortByPosition = false
        stripper.startPage = index + 1
        stripper.endPage = index + 1
        stripper.getText(document)

        val rawLines = makeLines(positions)
        val lines = rawLines.filterNot { isPageFurniture(it, page.mediaBox.height) }
        val textBlocks = makeBlocks(lines, page.mediaBox.width)
        val captions = textBlocks.filter { it.caption }
        val visuals = detectVisuals(page, captions)

        val objects = mutableListOf<ReadingBlock>()
        objects += textBlocks.map {
            ReadingBlock.Text(
                text = it.text,
                page = index,
                top = it.top,
                bottom = it.bottom,
                left = it.left,
                right = it.right,
                heading = it.heading,
                caption = it.caption
            )
        }
        objects += visuals.map {
            ReadingBlock.Visual(
                page = index,
                top = it.top,
                bottom = it.bottom,
                left = it.left,
                right = it.right,
                cropLeft = it.cropLeft,
                cropTop = it.cropTop,
                cropRight = it.cropRight,
                cropBottom = it.cropBottom
            )
        }

        // Reading order is geometric only after page regions have been
        // classified. Visuals are now given real page-relative positions.
        val ordered = objects.sortedWith(
            compareBy<ReadingBlock> { it.top }
                .thenBy { if (it is ReadingBlock.Visual) 0 else 1 }
                .thenBy { it.left }
        )

        return PageModel(
            index = index,
            width = page.mediaBox.width,
            height = page.mediaBox.height,
            blocks = ordered
        )
    }

    private fun makeLines(chars: List<TextPosition>): List<Line> {
        if (chars.isEmpty()) return emptyList()

        val sorted = chars.sortedWith(
            compareBy<TextPosition> { it.y }.thenBy { it.x }
        )

        val rows = mutableListOf<MutableList<TextPosition>>()

        for (character in sorted) {
            val last = rows.lastOrNull()
            if (last == null) {
                rows += mutableListOf(character)
                continue
            }

            val referenceY = last.first().y
            val tolerance = max(2.5f, character.height * 0.35f)

            if (abs(referenceY - character.y) <= tolerance) {
                last += character
            } else {
                rows += mutableListOf(character)
            }
        }

        return rows.mapNotNull { row ->
            val ordered = row.sortedBy { it.x }
            val text = normalizePdfText(wordAware(ordered)).trim()
            if (text.isBlank()) {
                null
            } else {
                val fontSize = ordered.map { it.fontSizeInPt }.average().toFloat()
                Line(
                    text = text,
                    left = ordered.minOf { it.x },
                    right = ordered.maxOf { it.x + it.width },
                    top = ordered.minOf { it.y },
                    bottom = ordered.maxOf { it.y + it.height },
                    fontSize = fontSize
                )
            }
        }
    }

    /**
     * This PDF family uses a private-use font encoding for digits. PDFBox
     * therefore exposes 0..9 as U+F730..U+F739. Convert only that known
     * range; ordinary Unicode is left untouched.
     */
    private fun normalizePdfText(text: String): String {
        return buildString(text.length) {
            for (ch in text) {
                when (ch.code) {
                    in 0xF730..0xF739 -> append(('0'.code + (ch.code - 0xF730)).toChar())
                    else -> append(ch)
                }
            }
        }
    }

    private fun wordAware(chars: List<TextPosition>): String {
        val out = StringBuilder()

        for (i in chars.indices) {
            val current = chars[i]
            if (i > 0) {
                val previous = chars[i - 1]
                val gap = current.x - (previous.x + previous.width)
                val averageWidth = max(0.5f, (previous.width + current.width) / 2f)

                if (
                    gap > averageWidth * 0.55f &&
                    out.isNotEmpty() &&
                    !out.last().isWhitespace()
                ) {
                    out.append(' ')
                }
            }
            out.append(current.unicode ?: "")
        }

        return out.toString().replace(Regex("[ \\t]+"), " ")
    }

    private fun isPageFurniture(line: Line, pageHeight: Float): Boolean {
        val text = line.text.trim()
        if (text.isBlank()) return true

        // Printer/header metadata found repeatedly in the supplied historical PDF.
        if (text.contains("5702 History of Neurology", ignoreCase = true)) return true
        if (text.contains("Pagina", ignoreCase = true)) return true

        val normalized = text.replace(Regex("\\s+"), " ").trim()

        if (
            normalized.matches(
                Regex("\\d+ \\| HISTORY OF NEUROLOGY IN THE NETHERLANDS", RegexOption.IGNORE_CASE)
            )
        ) return true

        if (
            normalized.matches(
                Regex("NEUROANATOMY \\| \\d+", RegexOption.IGNORE_CASE)
            )
        ) return true

        // Repeated running titles/footers in the pathology PDF.
        if (
            normalized.equals("The Pathology of Cancer", ignoreCase = true) &&
            (line.top < 65f || line.bottom > pageHeight - 65f)
        ) return true

        if (
            normalized.contains("Cancer Concepts: A Guidebook for the Non-Oncologist", true) &&
            line.bottom > pageHeight - 80f
        ) return true

        // Isolated page numbers are navigation furniture when they occur at an edge.
        if (normalized.matches(Regex("\\d+")) && (line.top < 95f || line.bottom > pageHeight - 30f)) {
            return true
        }

        return false
    }

    private fun makeBlocks(lines: List<Line>, pageWidth: Float): List<Block> {
        if (lines.isEmpty()) return emptyList()

        val columns = splitIntoColumns(lines, pageWidth)
        val result = mutableListOf<Block>()

        for (column in columns) {
            var current = mutableListOf<Line>()

            fun flush() {
                if (current.isEmpty()) return

                val joined = joinLines(current)
                if (joined.isNotEmpty()) {
                    val fontSize = current.map { it.fontSize }.average().toFloat()
                    val heading = current.size <= 2 && fontSize >= 11.2f
                    val caption = isCaption(joined)

                    result += Block(
                        text = joined,
                        left = current.minOf { it.left },
                        right = current.maxOf { it.right },
                        top = current.minOf { it.top },
                        bottom = current.maxOf { it.bottom },
                        heading = heading && !caption,
                        caption = caption
                    )
                }
                current = mutableListOf()
            }

            for (line in column.sortedWith(compareBy<Line> { it.top }.thenBy { it.left })) {
                if (current.isEmpty()) {
                    current += line
                    continue
                }

                val previous = current.last()
                val lineHeight = max(1f, previous.bottom - previous.top)
                val verticalGap = line.top - previous.bottom
                val indentShift = abs(line.left - previous.left)

                val captionBoundary = isCaption(line.text) != isCaption(current.first().text)
                val headingBoundary = isHeadingLine(line) && current.size > 1

                val newBlock =
                    verticalGap > lineHeight * 1.15f ||
                        (indentShift > pageWidth * 0.10f && verticalGap > lineHeight * 0.20f) ||
                        captionBoundary ||
                        headingBoundary

                if (newBlock) flush()
                current += line
            }
            flush()
        }

        return result
    }

    private fun joinLines(lines: List<Line>): String {
        val out = StringBuilder()
        for (line in lines) {
            val part = line.text.trim()
            if (part.isEmpty()) continue

            if (out.isNotEmpty()) {
                // Remove a PDF line-break hyphen when it clearly represents
                // word hyphenation rather than a real compound word.
                if (out.last() == '-' && part.first().isLowerCase()) {
                    out.setLength(out.length - 1)
                    out.append(part)
                    continue
                }
                out.append(' ')
            }
            out.append(part)
        }
        return out.toString().replace(Regex("\\s+"), " ").trim()
    }

    private fun isHeadingLine(line: Line): Boolean {
        return line.fontSize >= 11.2f
    }

    private fun isCaption(text: String): Boolean {
        val t = text.trim()
        return t.matches(
            Regex("^(Figures?|Fig\\.?|Tables?)\\s*(?:[0-9]+[A-Za-z]?|[IVXivx]+)?\\s*[.:,-]?.*", RegexOption.IGNORE_CASE)
        ) || t.matches(Regex("^(Figures?|Tables?)\\s*[.:,-].*", RegexOption.IGNORE_CASE))
    }

    private fun splitIntoColumns(lines: List<Line>, pageWidth: Float): List<List<Line>> {
        if (lines.isEmpty()) return emptyList()

        val left = mutableListOf<Line>()
        val right = mutableListOf<Line>()
        val fullWidth = mutableListOf<Line>()
        val midpoint = pageWidth / 2f
        val gutter = pageWidth * 0.055f

        for (line in lines) {
            val spansCenter = line.left < midpoint - gutter && line.right > midpoint + gutter
            if (spansCenter || line.right - line.left > pageWidth * 0.72f) {
                fullWidth += line
            } else if (line.right <= midpoint - gutter) {
                left += line
            } else if (line.left >= midpoint + gutter) {
                right += line
            } else {
                fullWidth += line
            }
        }

        val hasTwoColumns =
            left.size >= 6 && right.size >= 6 &&
                left.size.toFloat() / max(1, lines.size) > 0.18f &&
                right.size.toFloat() / max(1, lines.size) > 0.18f

        if (!hasTwoColumns) {
            return listOf(lines.sortedWith(compareBy<Line> { it.top }.thenBy { it.left }))
        }

        val earlyFull = fullWidth.filter {
            it.top <= minOf(left.minOf { l -> l.top }, right.minOf { l -> l.top })
        }.sortedBy { it.top }

        val lateFull = fullWidth.filter { it !in earlyFull }.sortedBy { it.top }

        return buildList {
            if (earlyFull.isNotEmpty()) add(earlyFull)
            add(left.sortedWith(compareBy<Line> { it.top }.thenBy { it.left }))
            add(right.sortedWith(compareBy<Line> { it.top }.thenBy { it.left }))
            if (lateFull.isNotEmpty()) add(lateFull)
        }
    }

    /**
     * Associate page-level raster figures/tables with their nearby caption.
     * We do not OCR image contents. Instead, the actual PDF page is rendered
     * and a crop is taken, so vector artwork and raster images both survive.
     */
    private fun detectVisuals(page: PDPage, captions: List<Block>): List<VisualSpec> {
        if (captions.isEmpty()) return emptyList()

        // PDF resources often expose an image and its mask as two XObjects.
        // Collapse consecutive duplicates so image-to-caption association stays
        // aligned on pages containing several figures.
        val imageInfo = mutableListOf<Pair<Int, Int>>()
        val resources = page.resources
        if (resources != null) {
            for (name in resources.xObjectNames) {
                try {
                    val xObject: PDXObject = resources.getXObject(name)
                    if (xObject is PDImageXObject) {
                        val pair = xObject.image.width to xObject.image.height
                        if (imageInfo.lastOrNull() != pair) imageInfo += pair
                    }
                } catch (_: Throwable) {
                    // Ignore one malformed/unsupported visual.
                }
            }
        }

        if (imageInfo.isEmpty()) return emptyList()

        val pageWidth = page.mediaBox.width
        val pageHeight = page.mediaBox.height
        val midpoint = pageWidth / 2f
        val gutter = pageWidth * 0.055f
        val result = mutableListOf<VisualSpec>()

        captions.take(imageInfo.size).forEachIndexed { index, caption ->
            val isTable = caption.text.trim().startsWith("Table", true)
            val (iw, ih) = imageInfo[index]
            val captionWidth = caption.right - caption.left
            val isLeftColumn = caption.right <= midpoint + gutter && caption.left < midpoint
            val isRightColumn = caption.left >= midpoint - gutter && caption.right > midpoint

            if (captionWidth < pageWidth * 0.30f) {
                // Side caption: the artwork is normally immediately to its left.
                val right = (caption.left - 8f).coerceAtLeast(pageWidth * 0.35f)
                val left = (right - pageWidth * 0.53f).coerceAtLeast(0f)
                val top = (caption.top - pageHeight * 0.16f).coerceAtLeast(45f)
                val bottom = (caption.bottom + 8f).coerceAtMost(pageHeight - 10f)
                result += VisualSpec(top, bottom, left, right, left, top, right, bottom)
            } else if (isTable) {
                // Historical table pages can contain rotated/encoded artwork;
                // a broad crop is safer than trusting the raw image aspect ratio.
                val left = pageWidth * 0.10f
                val right = pageWidth * 0.90f
                val top = pageHeight * 0.10f
                val bottom = (caption.top - 6f).coerceAtLeast(top + 20f)
                result += VisualSpec(top, bottom, left, right, left, top, right, bottom)
            } else {
                val targetWidth: Float
                val left: Float

                when {
                    isLeftColumn -> {
                        targetWidth = pageWidth * 0.40f
                        left = pageWidth * 0.055f
                    }
                    isRightColumn -> {
                        targetWidth = pageWidth * 0.40f
                        left = midpoint + pageWidth * 0.015f
                    }
                    else -> {
                        targetWidth = pageWidth * 0.74f
                        left = (pageWidth - targetWidth) / 2f
                    }
                }

                val aspect = ih.toFloat() / max(1, iw).toFloat()
                val targetHeight = min(pageHeight * 0.58f, targetWidth * aspect)
                val bottom = (caption.top - 7f).coerceAtLeast(25f)
                val top = (bottom - targetHeight).coerceAtLeast(35f)
                val right = min(pageWidth - 8f, left + targetWidth)

                result += VisualSpec(top, bottom, left, right, left, top, right, bottom)
            }
        }

        return result
    }

    private fun render() {
        val model = documentModel ?: return
        if (readingMode) {
            modeButton.text = "Original"
            readingScroll.visibility = View.VISIBLE
            originalScroll.visibility = View.GONE
            renderReading(model)
        } else {
            modeButton.text = "Reading"
            readingScroll.visibility = View.GONE
            originalScroll.visibility = View.VISIBLE
            renderOriginal(model)
        }
    }

    private fun renderReading(model: ReadingDocument) {
        readingContainer.removeAllViews()

        for (page in model.pages) {
            val pageLabel = TextView(this).apply {
                text = "Page ${page.index + 1}"
                textSize = 11f
                setTextColor(Color.GRAY)
                setPadding(4, 16, 4, 5)
            }
            readingContainer.addView(pageLabel)

            for (block in page.blocks) {
                when (block) {
                    is ReadingBlock.Text -> {
                        val view = TextView(this).apply {
                            text = block.text
                            setTextColor(
                                ContextCompat.getColor(
                                    this@MainActivity,
                                    R.color.reader_text
                                )
                            )
                            setLineSpacing(0f, if (block.heading) 1.05f else 1.18f)
                            setPadding(4, if (block.heading) 10 else 5, 4, if (block.heading) 7 else 9)

                            if (block.heading) {
                                textSize = 20f
                                setTypeface(typeface, Typeface.BOLD)
                            } else if (block.caption) {
                                textSize = 15f
                                setTypeface(typeface, Typeface.ITALIC)
                            } else {
                                textSize = 18f
                            }
                        }
                        readingContainer.addView(view)
                    }

                    is ReadingBlock.Visual -> {
                        val bitmap = renderCrop(block)
                        if (bitmap != null) {
                            val visualLabel = TextView(this).apply {
                                text = "Figure / visual from page ${block.page + 1}"
                                textSize = 11f
                                setTextColor(Color.GRAY)
                                setPadding(4, 8, 4, 2)
                            }
                            readingContainer.addView(visualLabel)
                            readingContainer.addView(
                                ImageView(this).apply {
                                    setImageBitmap(bitmap)
                                    adjustViewBounds = true
                                    scaleType = ImageView.ScaleType.FIT_CENTER
                                    setPadding(0, 6, 0, 8)
                                    setOnClickListener { jumpToPage(block.page) }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun renderCrop(block: ReadingBlock.Visual): Bitmap? {
        val uri = currentUri ?: return null
        return try {
            val descriptor = contentResolver.openFileDescriptor(uri, "r") ?: return null
            descriptor.use { fd ->
                PdfRenderer(fd).use { renderer ->
                    if (block.page !in 0 until renderer.pageCount) return null
                    renderer.openPage(block.page).use { page ->
                        val scale = 2.0f
                        val pageWidth = page.width.toFloat()
                        val pageHeight = page.height.toFloat()

                        val left = (block.cropLeft / documentModel!!.pages[block.page].width * pageWidth)
                            .toInt().coerceIn(0, page.width - 1)
                        val top = (block.cropTop / documentModel!!.pages[block.page].height * pageHeight)
                            .toInt().coerceIn(0, page.height - 1)
                        val right = (block.cropRight / documentModel!!.pages[block.page].width * pageWidth)
                            .toInt().coerceIn(left + 1, page.width)
                        val bottom = (block.cropBottom / documentModel!!.pages[block.page].height * pageHeight)
                            .toInt().coerceIn(top + 1, page.height)

                        val cropW = right - left
                        val cropH = bottom - top
                        val outW = max(1, (cropW * scale).toInt())
                        val outH = max(1, (cropH * scale).toInt())
                        val bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
                        bitmap.eraseColor(Color.WHITE)

                        val scaleX = outW.toFloat() / page.width
                        val scaleY = outH.toFloat() / page.height
                        val matrix = Matrix().apply {
                            setScale(scaleX, scaleY)
                            postTranslate(-left * scaleX, -top * scaleY)
                        }

                        // PdfRenderer clips to the destination bitmap. The
                        // translation above maps the requested page rectangle
                        // into that bitmap without requiring a full-page bitmap.
                        page.render(
                            bitmap,
                            null,
                            matrix,
                            PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
                        )
                        bitmap
                    }
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun renderOriginal(model: ReadingDocument) {
        originalScroll.adapter = OriginalPageAdapter(model.pages.size)
    }

    private inner class OriginalPageAdapter(
        private val pageCount: Int
    ) : RecyclerView.Adapter<OriginalPageAdapter.PageHolder>() {

        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): PageHolder {
            val image = ImageView(parent.context).apply {
                layoutParams = RecyclerView.LayoutParams(
                    RecyclerView.LayoutParams.MATCH_PARENT,
                    RecyclerView.LayoutParams.WRAP_CONTENT
                ).also { it.bottomMargin = 12 }
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(Color.WHITE)
            }
            return PageHolder(image)
        }

        override fun onBindViewHolder(holder: PageHolder, position: Int) {
            holder.boundPage = position
            holder.image.setImageDrawable(null)
            scope.launch {
                val bitmap = withContext(Dispatchers.IO) { renderPage(position) }
                if (holder.boundPage == position && bitmap != null) {
                    holder.image.setImageBitmap(bitmap)
                }
            }
        }

        override fun onViewRecycled(holder: PageHolder) {
            holder.boundPage = RecyclerView.NO_POSITION
            holder.image.setImageDrawable(null)
            super.onViewRecycled(holder)
        }

        override fun getItemCount(): Int = pageCount

        inner class PageHolder(val image: ImageView) : RecyclerView.ViewHolder(image) {
            var boundPage: Int = RecyclerView.NO_POSITION
        }
    }

    private fun renderPage(index: Int): Bitmap? {
        val uri = currentUri ?: return null
        return try {
            val descriptor = contentResolver.openFileDescriptor(uri, "r") ?: return null
            descriptor.use { fd ->
                PdfRenderer(fd).use { renderer ->
                    if (index !in 0 until renderer.pageCount) return null
                    renderer.openPage(index).use { page ->
                        val width = 1000
                        val height = max(1, (width.toFloat() * page.height / page.width).toInt())
                        Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { bitmap ->
                            bitmap.eraseColor(Color.WHITE)
                            page.render(
                                bitmap,
                                null,
                                null,
                                PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
                            )
                        }
                    }
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun jumpToPage(page: Int) {
        readingMode = false
        render()
        originalScroll.post {
            originalScroll.smoothScrollToPosition(
                page.coerceIn(0, max(0, (documentModel?.pages?.size ?: 1) - 1))
            )
        }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(
            uri,
            arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return null
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    data class ReadingDocument(val title: String, val pages: List<PageModel>)

    data class PageModel(
        val index: Int,
        val width: Float,
        val height: Float,
        val blocks: List<ReadingBlock>
    )

    sealed class ReadingBlock {
        abstract val page: Int
        abstract val top: Float
        abstract val bottom: Float
        abstract val left: Float
        abstract val right: Float

        data class Text(
            val text: String,
            override val page: Int,
            override val top: Float,
            override val bottom: Float,
            override val left: Float,
            override val right: Float,
            val heading: Boolean,
            val caption: Boolean
        ) : ReadingBlock()

        data class Visual(
            override val page: Int,
            override val top: Float,
            override val bottom: Float,
            override val left: Float,
            override val right: Float,
            val cropLeft: Float,
            val cropTop: Float,
            val cropRight: Float,
            val cropBottom: Float
        ) : ReadingBlock()
    }

    data class Line(
        val text: String,
        val left: Float,
        val right: Float,
        val top: Float,
        val bottom: Float,
        val fontSize: Float
    )

    data class Block(
        val text: String,
        val left: Float,
        val right: Float,
        val top: Float,
        val bottom: Float,
        val heading: Boolean,
        val caption: Boolean
    )

    data class VisualSpec(
        val top: Float,
        val bottom: Float,
        val left: Float,
        val right: Float,
        val cropLeft: Float,
        val cropTop: Float,
        val cropRight: Float,
        val cropBottom: Float
    )
}
